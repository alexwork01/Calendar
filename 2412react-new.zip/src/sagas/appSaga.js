import {
  call,
  put,
  all,
  takeEvery,
  delay,
  take,
  actionChannel,
  fork,
  select,
  takeLatest
} from 'redux-saga/effects';

function* handleInitApp() {
  yield console.log('handleInitApp');
}

export default function* watchAppSaga() {
  yield takeLatest('INIT_APP', handleInitApp);
}
