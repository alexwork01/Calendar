import React from 'react';
import Header from '../../ui-kit/Header';

export default ({ children }) => (
  <div>
    <Header />
    {children}
  </div>
);
