import { connect } from 'react-redux';
import { compose } from 'redux';
import { withTheme } from 'styled-components';
import Home from './HomeRoute';

const mapStateToProps = state => ({
  user: state.user
});

const mapDispatchToProps = dispatch => ({});

export default compose(
  withTheme,
  connect(
    mapStateToProps,
    mapDispatchToProps
  )
)(Home);
