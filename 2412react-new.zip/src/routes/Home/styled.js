import styled from 'styled-components';
import Icon from './assets/icon.svg';

export const ThemedIcon = styled(Icon)`
  width: 100px;
  height: 100px;
  fill: ${theme.background};
`;
