import React from 'react';

export default () => (
  <div>
    <p>This is About Route.</p>
  </div>
);
