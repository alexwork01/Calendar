import React from 'react';

export default props => {
  const { error, pastDelay } = props;

  if (error) {
    return (
      <div style={{ textAlign: 'center' }}>
        Error!
        <button onClick={props.retry}>Retry</button>
      </div>
    );
  }

  if (pastDelay) {
    return (
      <div style={{ textAlign: 'center', width: '100%', height: '200px' }}>
        Dynamic loading...
      </div>
    );
  }

  return null;
};
