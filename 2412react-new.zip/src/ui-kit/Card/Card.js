import React, { useEffect, useState } from 'react';
import { Grid, Image, Transition, Segment, Header } from 'semantic-ui-react';

export const Card = props => {
  const { label } = props;

  return (
    <Segment>
      <div style={{ position: 'relative', color: 'grey', textAlign: 'center' }}>
        <div
          style={{
            backgroundColor: '#fff',
            boxShadow: 'rgb(1, 159, 203) 0px 0px 0px 2px',
            borderRadius: '50%',
            height: '170px',
            width: '170px',
            textAlign: 'center',
            position: 'relative',
            overflow: 'hidden',
            transition: 'color 0.2s easy'
          }}
        >
          <span
            style={{
              fontSize: '35px',
              lineHeight: '110px',
              marginTop: '-50px',
              position: 'absolute',
              top: '80px',
              right: '0px',
              left: '0px'
            }}
          >
            {label}
          </span>
        </div>
      </div>
    </Segment>
  );
};
