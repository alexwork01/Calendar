import { withTheme } from 'styled-components';
import Header from './Header';

export default withTheme(Header);
