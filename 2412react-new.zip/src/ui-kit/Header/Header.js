import React, { useEffect, useState } from 'react';
import { Grid, Image, Transition } from 'semantic-ui-react';

import headerImg from '../../assets/iphone.png';
import { BackgroundWave, HeadingText } from './components';
import {
  BackgroundImage,
  BackgroundOverlay,
  HeaderWrapper,
  ImageContainer,
  MediaWrapper
} from './styled';

export default () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const delay = setTimeout(() => setVisible(true), 300);

    return () => clearTimeout(delay);
  }, []);

  return (
    <HeaderWrapper textAlign="center" vertical>
      <BackgroundImage />
      <BackgroundOverlay />
      <Grid stackable>
        <Grid.Row>
          <Grid.Column width={8}>
            <HeadingText />
          </Grid.Column>
          <Grid.Column width={8}>
            <MediaWrapper>
              <Transition.Group animation="slide up" duration={500}>
                {visible && (
                  <ImageContainer>
                    <Image src={headerImg} />
                  </ImageContainer>
                )}
              </Transition.Group>
            </MediaWrapper>
          </Grid.Column>
        </Grid.Row>
      </Grid>
      <BackgroundWave />
    </HeaderWrapper>
  );
};
