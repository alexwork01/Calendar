import styled from 'styled-components';
import { Segment } from 'semantic-ui-react';
import bgImage from '../../assets/bg.jpg';

export const HeaderWrapper = styled(Segment)`
  position: relative;
  background: ${props => props.theme.backgroundDefault}!important;
  min-height: 22em;
  padding: 0 0 0 0;
  border: 0 !important;
  border-width: 0 !important;

  @media (min-width: 768px) {
    min-height: 44em;
  }
`;

export const BackgroundImage = styled.div`
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  opacity: 0.3;
  background-image: url(${bgImage});
  background-repeat: no-repeat;
  background-position: center center;
  background-size: cover;
  background-attachment: scroll;
`;

export const BackgroundOverlay = styled.div`
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  opacity: 0.7;
  background-image: ${props => props.theme.header.gradient};
  background-size: auto;
`;

export const MediaWrapper = styled.div`
  display: flex;
  justify-content: center;
  position: relative;
  max-height: 20em;
  overflow: hidden;
  margin-bottom: -1em;

  @media (min-width: 768px) {
    max-height: 44em;
  }
`;

export const ImageContainer = styled.div`
  max-width: 420px;
  width: 80%;
`;
