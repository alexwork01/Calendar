export { HeadingText } from './HeadingText';
