export { BackgroundWave } from './Wave';
