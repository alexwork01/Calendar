import createTheme from 'styled-components-theme';

export const themeConfig = {
  textDefault: 'rgba(0,0,0,.8)',
  textSecondary: '#ffffff',
  textThird: 'rgba(255,255,255,.8)',
  backgroundDefault: '#ffffff'
};

themeConfig.header = {
  gradient: `linear-gradient(to bottom,  #46aef7 0%,#30c7ec 53%,#16d9e3 100%)`
};

const theme = createTheme(...Object.keys(themeConfig));
export default theme;


