import { createGlobalStyle } from 'styled-components';
import { themeConfig } from './theme';

export default createGlobalStyle`
  @import url('https://fonts.googleapis.com/css?family=Roboto');
  @import url('https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap');
  
  body {
    background: ${themeConfig.backgroundDefault};
    color: rgba(0,0,0,.8);
    font-family: 'Roboto';
    margin: 0;
  }
`;
