export default (state = { works: true, hmr: 'yeah' }, action) => {
  switch (action.type) {
    case 'TEST':
      return { ...state, works: 'TEST2', awesome: true };
    default:
      return state;
  }
};
