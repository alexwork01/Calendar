import React from 'react';
import { Route } from 'react-router-dom';
import Loadable from 'react-loadable';

// Styling
import AppLayout from '../layout/AppLayout';

// Routes
import Home from '../routes/Home';

// Components
import Loading from '../ui-kit/Loading';

const DynamicHome = Loadable({
  loader: () => import('../routes/Home'),
  loading: Loading,
});

const DynamicAbout = Loadable({
  loader: () => import('../routes/About'),
  loading: Loading,
});

export default () => (
  <AppLayout>
    <Route exact path="/" component={DynamicHome} />
    <Route path="/about" component={DynamicAbout} />
  </AppLayout>
);
